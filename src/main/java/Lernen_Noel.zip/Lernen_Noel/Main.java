package Lernen_Noel;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        /*ServerSocket serverSocket = new ServerSocket(50000);
        Socket client = serverSocket.accept();

        while (true) {
            Scanner in = new Scanner(client.getInputStream());
            String text = in.nextLine();
            System.out.println(text);
            PrintWriter out = new PrintWriter(client.getOutputStream(), true);
            out.println("twfdtwfdujwfdzwd" + text);
        }*/
        Server test = new Server();
        test.testMethod();
    }
}
