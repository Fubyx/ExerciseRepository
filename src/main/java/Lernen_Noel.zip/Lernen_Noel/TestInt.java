package Lernen_Noel;

public interface TestInt {
    public default void testMethod(){
        System.out.println("Hallo");
    }
}
